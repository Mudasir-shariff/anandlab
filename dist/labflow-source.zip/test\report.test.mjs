import assert from 'node:assert/strict';
import { TESTS, PARAMETERS, makeSampleReportOrder } from '../dist/catalog.js';
import { REPORT_TEMPLATES, renderReport } from '../dist/report.js';

const profile = { labName:'Example Diagnostics', address:'Example address', phone:'+91 00000 00000', email:'example@example.test', registration:'EX-100', labIncharge:'Example technician', labInchargeQualification:'DMLT', pathologist:'Example reviewer', pathologistQualification:'MD (Pathology)', reportFooter:'Please correlate clinically.', workingHours:'9 am–6 pm' };
const count = (text,pattern) => [...text.matchAll(pattern)].length;
for (const code of Object.keys(TESTS)) {
  const order = makeSampleReportOrder(code);
  for (const template of REPORT_TEMPLATES) {
    const html = renderReport(order,profile,{template:template.id,preview:true});
    assert(html.includes(`report-theme-${template.id}`));
    assert(html.includes('SAMPLE REPORT'));
    assert(html.includes(order.name));
    assert.equal(count(html,/class="report-result-row /g),TESTS[code].parameters.length,`${code} must display every ordered result`);
    for (const key of TESTS[code].parameters) assert(html.includes(`data-parameter="${key}"`));
    assert(html.includes('Page 1 of 1'));
  }
}
const sample = makeSampleReportOrder('CBC');
const before = JSON.stringify(sample);
const escaped = renderReport({...sample,name:'<img src=x onerror=alert(1)>',notes:'<script>bad()</script>'},{...profile,labName:'Lab <script>bad()</script>'});
assert(!escaped.includes('<script>'));
assert(!escaped.includes('<img src='));
assert(escaped.includes('&lt;script&gt;'));
assert.equal(JSON.stringify(sample),before,'rendering must never mutate a clinical record');

const noValues = renderReport({...sample,results:{hb:0,wbc:null}},profile);
assert.match(noValues,/<td class="report-result-value">0<span/,'a measured zero must be retained and flagged');
assert.match(noValues,/data-parameter="wbc"><td>[^<]+<\/td><td class="report-result-value">—<\/td>/,'missing result must display a dash, never zero');
const highLow = renderReport({...sample,results:{hb:1,wbc:100000}},profile);
assert(highLow.includes('Below reference range'));
assert(highLow.includes('Above reference range'));

const frozen = renderReport({...sample,reportSnapshot:{...profile,labName:'Original approved laboratory',reportTemplate:'sahara'}},{...profile,labName:'New laboratory'});
assert(frozen.includes('Original approved laboratory'));
assert(!frozen.includes('New laboratory'));
assert(frozen.includes('report-theme-sahara'));
assert(renderReport({...sample,reportSnapshot:{...profile,reportTemplate:'sahara'}},profile,{template:'minimal'}).includes('report-theme-minimal'));
assert(renderReport(sample,profile,{template:'<script>'}).includes('report-theme-classic'));
assert(renderReport({...sample,status:'Review',sampleReport:false,demo:false},profile).includes('DRAFT REPORT'));

const codes = Object.keys(TESTS);
const combined = {...sample,tests:codes,results:Object.assign({},...codes.map(code=>makeSampleReportOrder(code).results))};
const multipage = renderReport(combined,profile);
const pageCount = count(multipage,/<article class="report-page"/g);
assert(pageCount > 1,'15 panels must paginate');
for (let page=1;page<=pageCount;page++) assert(multipage.includes(`Page ${page} of ${pageCount}`));
assert.equal(count(multipage,/class="report-result-row /g),codes.reduce((sum,code)=>sum+TESTS[code].parameters.length,0),'pagination must not omit or duplicate results');
assert.equal(count(multipage,/class="report-brand"/g),pageCount,'every page must repeat laboratory identity');
assert.equal(count(multipage,/class="report-patient-block"/g),pageCount,'every page must repeat patient identity');
console.log(`PASS: ${codes.length} test panels × 3 templates, result completeness, escaping, zero/missing values, flags, frozen profiles, draft status, and ${pageCount}-page combined report.`);
const manyNotes = Array.from({length:90},(_,i)=>`Clinical note line ${i+1}.`).join('\n');
const noteReport = renderReport({...sample,notes:manyNotes},profile);
assert(count(noteReport,/<article class="report-page"/g) > 1,'long notes require their own numbered pages');
for (const line of manyNotes.split('\n')) assert(noteReport.includes(line),'all clinical note text must be preserved');
const denseOrder = {...sample,tests:['CBC','THYROID'],results:{...makeSampleReportOrder('CBC').results,...makeSampleReportOrder('THYROID').results},notes:'Concise clinical note.'};
const denseReport = renderReport(denseOrder,profile);
assert.equal(count(denseReport,/<article class="report-page"/g),2,'a dense last results page must reserve a completion page for notes and reviewers');
const longProse = 'Review together with the relevant clinical information. '.repeat(12);
const proseReport = renderReport({...sample,notes:longProse},profile);
assert(count(proseReport,/<article class="report-page"/g)>1,'notes over300 characters must receive their own completion pages');

// Released reports retain their exact historical rows, units and reference ranges.
const archivedParameters=Object.fromEntries(TESTS.CBC.parameters.slice(0,13).map(key=>[key,{...PARAMETERS[key]}]));
archivedParameters.hb={...archivedParameters.hb,unit:'ARCHIVED-UNIT',reference:'ARCHIVED-RANGE',min:1,max:99};
const archived={...sample,sampleReport:false,demo:false,catalogSnapshot:{tests:{CBC:{...TESTS.CBC,parameters:TESTS.CBC.parameters.slice(0,13)}},parameters:archivedParameters},results:Object.fromEntries(TESTS.CBC.parameters.slice(0,13).map(key=>[key,sample.results[key]]))};
const archiveHtml=renderReport(archived,profile);
assert(archiveHtml.includes('ARCHIVED-UNIT'));
assert(archiveHtml.includes('ARCHIVED-RANGE'));
assert.equal(count(archiveHtml,/class="report-result-row /g),13,'new live CBC analytes must not be added to a released report');
assert(!archiveHtml.includes('data-parameter="rdw_cv"'));
assert(!archiveHtml.includes('Historical report:'));

for(const invalid of [' ',false,true,[],{},'0x10','NaN','Infinity']){
 const html=renderReport({...sample,results:{hb:invalid}},profile);
 assert.match(html,/data-parameter="hb"><td>[^<]+<\/td><td class="report-result-value">—<\/td>/,`${String(invalid)} must not become a measured result`);
}
const draftDemo=renderReport({...sample,status:'Processing'},profile,{demo:true,preview:true});
assert(draftDemo.includes('DRAFT REPORT'),'demo and sample ribbons must still identify a draft');
assert(draftDemo.includes('Draft · not authorized'));
assert(!draftDemo.includes('Approved by'));
const legacyDate=renderReport({...archived,approvedAt:null,updatedAt:'2026-12-31T12:00:00Z'},profile);
assert.match(legacyDate,/<dt>Reported<\/dt><dd>Not recorded<\/dd>/,'billing time must never stand in for an unknown approval time');
const missingPanel=renderReport({...sample,tests:['REMOVED_PANEL'],results:{historical_assay:'Detected'}},profile);
assert(missingPanel.includes('REMOVED_PANEL · definition unavailable'));
assert(missingPanel.includes('Additional recorded results'));
assert(missingPanel.includes('Detected'),'recorded orphan result text must be retained');
assert(missingPanel.includes('Not captured'));
const missingParameter=renderReport({...archived,catalogSnapshot:{tests:{CBC:{...TESTS.CBC,parameters:['removed_parameter']}},parameters:{}},results:{removed_parameter:12}},profile);
assert(missingParameter.includes('removed_parameter'));
assert(missingParameter.includes('Definition not captured'));
assert(missingParameter.includes('>12</td>'));
const duplicateCode=renderReport({...sample,tests:['CBC','CBC']},profile);
assert.equal(count(duplicateCode,/class="report-result-row /g),TESTS.CBC.parameters.length,'duplicate order codes must not repeat a panel');
const shared=renderReport({...sample,tests:['TSH','THYROID'],results:{...makeSampleReportOrder('THYROID').results}},profile);
assert(shared.includes('data-test="TSH" data-parameter="tsh"'));
assert(shared.includes('data-test="THYROID" data-parameter="tsh"'),'a shared analyte remains identifiable within its panel');
const longProfile={...profile,labName:'Long laboratory name '.repeat(9),address:'Long laboratory address '.repeat(20),website:'https://example.test/'.repeat(20),reportFooter:'Laboratory footer information. '.repeat(16),pathologist:'Reviewer Name '.repeat(12),pathologistQualification:'Qualification '.repeat(12)};
const maximum=renderReport({...combined,notes:manyNotes},longProfile,{template:'sahara'});
assert(count(maximum,/<article class="report-page"/g)>pageCount,'long metadata must reduce available result space');
assert.equal(count(maximum,/class="report-result-row /g),codes.reduce((sum,code)=>sum+TESTS[code].parameters.length,0));
for(const line of manyNotes.split('\n'))assert(maximum.includes(line));
assert.equal(count(maximum,/class="report-reviewers"/g),1,'the authorization block occurs exactly once');
console.log('PASS: archived catalog definitions, strict numeric results, draft labels, immutable report date, missing definitions, duplicate panel identity, and long metadata pagination.');

import { writeFile, mkdir, stat, readFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { TESTS, PARAMETERS, makeSampleReportOrder } from '../dist/catalog.js';
import { renderReport, REPORT_TEMPLATES } from '../dist/report.js';

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const OUT_DIR = resolve(ROOT, 'work/pdf-verification');
await mkdir(OUT_DIR, { recursive: true });

const reportCss = await readFile(resolve(ROOT, 'dist/report.css'), 'utf8');

function wrapHtml(title, reportHtml) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${title}</title>
<style>
${reportCss}
body { margin: 0; padding: 20px; background: #eaeff2; }
@media print { body { padding: 0; background: white; } }
</style>
</head>
<body>
${reportHtml}
</body>
</html>`;
}

const chromePath = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';

const profile = {
  labName: 'Apex Precision Diagnostics',
  address: 'Plot 42, Hiranandani Business Park, Powai, Mumbai 400076',
  phone: '+91 22 2570 0000',
  email: 'reports@apexdiagnostics.in',
  registration: 'MAH-MUM-2024-NABL-0482',
  website: 'https://apexdiagnostics.in',
  labIncharge: 'Dr. Sunita Deshmukh, MSc, PhD',
  labInchargeQualification: 'Senior Biochemist & Quality Manager',
  pathologist: 'Dr. Anand Ramanathan, MD (Pathology)',
  pathologistQualification: 'Consultant Pathologist (Reg: MMC-2008/04/1234)',
  reportFooter: 'This report relates strictly to the sample received and tested. Quality controls verified. Correlate with clinical findings.',
  workingHours: 'Monday–Saturday: 7:00 AM – 9:00 PM | Sunday: 8:00 AM – 2:00 PM'
};

const scenarios = [
  {
    name: 'classic-cbc',
    title: 'Classic Layout - Complete Blood Count',
    template: 'classic',
    order: {
      ...makeSampleReportOrder('CBC'),
      name: 'Mrs. Priya Venkateshwaran-Chatterjee',
      age: 42,
      sex: 'Female',
      patientId: 'PT-2026-004812',
      referrer: 'Dr. Rajeshwari Swaminathan, MD, DM (Hematology)',
      notes: 'Hb and RBC indices consistent with mild microcytic hypochromic picture. Recommend serum ferritin and iron studies.'
    }
  },
  {
    name: 'minimal-thyroid',
    title: 'Minimal Layout - Thyroid & Metabolic Profile',
    template: 'minimal',
    order: {
      ...makeSampleReportOrder('THYROID'),
      name: 'Mr. Vikramaditya Harshavardhan Singhania',
      age: 58,
      sex: 'Male',
      patientId: 'PT-2026-009134',
      referrer: 'Dr. K. S. Murthy, MD (Endocrinology)',
      notes: 'Serum TSH elevated with borderline normal free thyroid hormones. Correlate with clinical symptoms and antibody titers.'
    }
  },
  {
    name: 'sahara-all-15-panels-multipage',
    title: 'Sahara Layout - 15-Panel Multipage Comprehensive Health Check',
    template: 'sahara',
    order: {
      id: 'LF-COMPREHENSIVE-2026',
      patientId: 'PT-2026-007721',
      name: 'Col. Devendraprasad Raghunathrao Mohite-Patil (Retd.)',
      age: 67,
      sex: 'Male',
      category: 'Corporate Master Health Check',
      referrer: 'Dr. Meenakshi Sundaram, MD (Internal Medicine)',
      tests: Object.keys(TESTS),
      status: 'Approved',
      createdAt: '2026-11-14T08:00:00.000Z',
      collectedAt: '2026-11-14T08:15:00.000Z',
      receivedAt: '2026-11-14T08:45:00.000Z',
      approvedAt: '2026-11-14T14:30:00.000Z',
      approvedBy: 'usr-path-001',
      approvedByName: 'Dr. Anand Ramanathan, MD (Pathology)',
      amount: Object.values(TESTS).reduce((sum, t) => sum + t.price, 0),
      paid: Object.values(TESTS).reduce((sum, t) => sum + t.price, 0),
      paymentMethod: 'UPI',
      results: Object.assign({}, ...Object.keys(TESTS).map(c => makeSampleReportOrder(c).results)),
      notes: 'Patient was fasting for 12 hours prior to collection. All parameters measured on calibrated automated analyzers.\nNo critical values encountered during routine processing.\nCorrelate lipid and glycemic parameters with dietary history and physical activity.\nFollow-up HbA1c recommended after 3 months.',
      resultsRevision: 1
    }
  }
];

const results = [];
for (const s of scenarios) {
  const htmlContent = wrapHtml(s.title, renderReport(s.order, profile, { template: s.template, demo: false }));
  const htmlPath = resolve(OUT_DIR, `${s.name}.html`);
  const pdfPath = resolve(OUT_DIR, `${s.name}.pdf`);
  await writeFile(htmlPath, htmlContent, 'utf8');

  // Generate real PDF with Chrome headless
  const proc = spawnSync(chromePath, [
    '--headless',
    '--disable-gpu',
    '--no-sandbox',
    '--no-pdf-header-footer',
    `--print-to-pdf=${pdfPath}`,
    htmlPath
  ], { encoding: 'utf8', timeout: 30000 });

  let pdfSize = 0;
  try {
    const s = await stat(pdfPath);
    pdfSize = s.size;
  } catch {}

  results.push({
    scenario: s.name,
    template: s.template,
    htmlFile: htmlPath,
    pdfFile: pdfPath,
    pdfSizeBytes: pdfSize,
    success: pdfSize > 5000
  });
}

console.log(JSON.stringify(results, null, 2));
